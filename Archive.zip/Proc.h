#include <stdio.h>
#include <stdlib.h>
#define BITS
void Pil(void);
void Goa(void);
void Hyd(void);
void Dub(void);

