#include "Proc.h"
int bits;
int main(void){
	Pil();
	printf("Bits - %p\n", &bits);


}
