#include <stdio.h>
#include <stdlib.h>

size_t tspace;
void* myalloc(size_t size);
void myfree(void* ptr);
